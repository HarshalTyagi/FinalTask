package com.soft.it.exception;
public class TaskNotFoundException extends RuntimeException{
	
	public TaskNotFoundException(String message){
		super(message);
	}
}
