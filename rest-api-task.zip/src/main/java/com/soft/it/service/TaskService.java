package com.soft.it.service;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import com.soft.it.dto.TaskDTO;
import com.soft.it.dto.TaskDTOWrapper;

@Service
public class TaskService {

	private String initialUri = "https://jsonmock.hackerrank.com/api/football_matches?year=";

	@Autowired
	private RestTemplate restTemplate;

	public List<TaskDTO> findTasksByDate(int year) {
		String baseURI = initialUri + year + "&page=";
		List<TaskDTO> totalTaskDTOs = new ArrayList<TaskDTO>();
		List<TaskDTO> currentTaskList;
		int page = 0;
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(List.of(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<>(headers);
		try {
			do {
				page++;
				URI uri = new URI(baseURI + page);
				ResponseEntity<TaskDTOWrapper> response = restTemplate.exchange(uri, HttpMethod.GET, entity,
						new ParameterizedTypeReference<>() {
						});
				currentTaskList = response.getBody().getData();
				if (!CollectionUtils.isEmpty(currentTaskList)) {
					totalTaskDTOs.addAll(currentTaskList);
				}
			} while (!CollectionUtils.isEmpty(currentTaskList));
		} catch (Exception ex) {
			return totalTaskDTOs;
		}
		return totalTaskDTOs.stream().filter(task -> task.getTeam1goals().equals(task.getTeam2goals()))
				.collect(Collectors.toList());
	}
}
