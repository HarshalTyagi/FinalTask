package com.soft.it.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.soft.it.dto.TaskDTO;
import com.soft.it.service.TaskService;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

@RestController
@RequestMapping("/v1")
@CrossOrigin(origins = "*")
public class TaskController {
	
	
	@Autowired
	private TaskService signupService;
	
	@Value("${jwt.secret.key:ABUE87%&$&##@)@(&@*^@^@@@}")
    private String jwtSecret;
			
	@PreAuthorize("hasAuthority('ADMIN')")
	@GetMapping("/task1")
	public Map<String,Object> task1(@RequestHeader("Authorization") String headerAuth) {
		Map<String,Object> map=new HashMap<String, Object>();
		if (StringUtils.hasText(headerAuth) && headerAuth.startsWith("Bearer ")) {
	    	headerAuth=headerAuth.substring(7, headerAuth.length());
	    	Claims claims=Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(headerAuth).getBody();
	    	map.put("username", claims.getSubject());
	    	map.put("role", claims.get("auth"));
	    	map.put("iat", claims.get("iat"));
	    	map.put("exp", claims.get("exp"));
		} 	  
		return map;
	}
	
	@PreAuthorize("hasAuthority('USER') OR hasAuthority('ADMIN')")
	@GetMapping("/task2")
	public Map<String,Object> task2(@RequestParam int year) {
		List<TaskDTO> taskDTOs=signupService.findTasksByDate(year);
		Map<String,Object> map=new HashMap<String, Object>();
		map.put("noOfMatchesDraw", taskDTOs.size());
		//map.put("matches", taskDTOs);
		return map;
	}
	
}
